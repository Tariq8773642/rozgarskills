ROZGARSKILLS STARTER WEBSITE

Files:
- index.html = complete starter website

How to use:
1. Open index.html in Chrome to preview the website.
2. To put it online for free, upload this file to a static hosting service such as GitHub Pages.
3. Before applying for AdSense, add substantial original articles, About, Contact and Privacy Policy pages and follow Google's current publisher policies.

Suggested website name:
RozgarSkills
Tagline:
Jobs, Skills & Career Guide for Pakistan
